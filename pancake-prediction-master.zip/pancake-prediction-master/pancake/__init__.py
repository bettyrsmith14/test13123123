from pancake.prediction import Prediction
