#!/usr/bin/env bash

export TZ=America/Montreal

source /venv/bin/activate
streamlit run main.py