import strategy.samebefore
import strategy.random
import strategy.bullish
import strategy.bearish
import strategy.trend
import strategy.ema
